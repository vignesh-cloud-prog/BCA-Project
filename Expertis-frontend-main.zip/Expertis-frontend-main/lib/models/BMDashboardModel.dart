class BMDashboardModel {
  String selectedIcon;
  String unSelectedIcon;
  String label;

  BMDashboardModel(
      {required this.label,
      required this.selectedIcon,
      required this.unSelectedIcon});
}
