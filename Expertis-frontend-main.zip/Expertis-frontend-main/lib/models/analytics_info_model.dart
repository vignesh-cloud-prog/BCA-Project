import 'package:flutter/material.dart';

class AnalyticInfo {
  String? svgSrc, title;
  int? count;
  Color? color;

  AnalyticInfo({
    this.svgSrc,
    this.title,
    this.count,
    this.color,
  });
}
