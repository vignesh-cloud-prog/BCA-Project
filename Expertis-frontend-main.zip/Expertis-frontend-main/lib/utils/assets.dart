class Assets {
  static const String defaultCategoryImage =
      'https://media.istockphoto.com/photos/barber-using-scissors-and-comb-picture-id640274128?b=1&k=20&m=640274128&s=170667a&w=0&h=SDQlyOIjIepH82icolK_6jTV3T_uQ3xUG9w6qft5mYI=';
  static const String defaultShopImage =
      'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8OHx8c2Fsb258ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60';
  static const String defaultServiceImage =
      'https://images.unsplash.com/photo-1580618672591-eb180b1a973f?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8aGFpcmN1dHxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60';
  static const String defaultUserImage =
      "https://w7.pngwing.com/pngs/178/595/png-transparent-user-profile-computer-icons-login-user-avatars-thumbnail.png";
}
