module.exports = {
  db: "mongodb://localhost/expertis",
};
