npm init

npm install express --save

npm install --save-dev nodemon

npm install mongoose --save

