exports.DEVELOPMENT_ENVIRONMENT = "development";
exports.PRODUCTION_ENVIRONMENT = "production";
exports.TEST_ENVIRONMENT = "test";
exports.TOKEN_EXPIRATION_TIME = "24h";
exports.APP_NAME = "Bablus";

