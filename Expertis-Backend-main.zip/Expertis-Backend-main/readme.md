# Expertis Backend

## To Run this Project via NPM follow below:

```bash

npm i
npm run server

```
